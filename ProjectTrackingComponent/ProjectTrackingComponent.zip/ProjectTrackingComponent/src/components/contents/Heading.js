import { HeadParagraph } from "../HomePageStyle";

const ContentHeading = () => {
  return (
    <HeadParagraph>
      <h1>POWERFUL INSIGHTS INTO YOUR TEAM</h1>
    </HeadParagraph>
  );
};

export default ContentHeading;
